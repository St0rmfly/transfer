﻿"""
SMTP Relay Script v1.5

Lostar Bilgi Güvenliği A.Ş.
2019

Geliştirilecek: local_hostname kaldırılacak, renkli ve sade sonuç üretilecek.
"""

# -*- coding: utf-8 -*-
import configparser
import smtplib
config = configparser.ConfigParser(strict=False)
#strict=False komutu gibi çözümler denendi ancak configParser "aynı IP, farklı port" durumlarında hatalı sonuç veriyor.

config.read('config.txt')

musteri1 = config.get('email','musteri1')
musteri2 = config.get('email','musteri2')
sahteic = config.get('email','sahteic')
lostar = config.get('email','lostar')
sahtedis = config.get('email','sahtedis')
tempmail = config.get('email','tempmail')

server = config.items('adres')

def mailsender(sender,receiver,message,ip,port):

    try:
        smtp = smtplib.SMTP(ip, port,"lostar",15)
        smtp.sendmail(sender,receiver,message)
        print("\e[96m+++ {}:{} sunucusunda {}'den {}'ye e-posta gonderilmesi BASARILI!".format(ip,port,sender,receiver))
    except Exception as error:
        print("\e[96m--- {}:{} sunucusunda {}'den {}'ye e-posta gonderilmesi basarisiz.".format(ip,port,sender,receiver))
        print("Hata Mesaji: " + str(error))

def mailcreator(mail1,mail2):
    sender = mail1
    receiver = mail2
    SUBJECT = "Lostar Test Hk."

    with open('config.txt') as input:
        for line in input:
            if line.strip() == '[adres]':
                break
        for line in input:
            if len(line.strip()) == 0:
                break
            ip, port = line.split(':', 1)
            port = port.rstrip()
            TEXT = "{}:{} sunucusundan yonlendirilen bu e-posta, Lostar Bilgi Guvenligi A.S'nin SMTP Relay testidir.\n{} adresinden {} adresine gonderilmistir.".format(ip,port,sender,receiver)
            message = 'Subject: {}\n\n{}'.format(SUBJECT, TEXT)
            mailsender(sender,receiver,message,ip,port)


mailcreator(musteri1,musteri1)	# Müşteri 1 > Müşteri 1
mailcreator(musteri2,musteri1)	# Müşteri 2 > Müşteri 1
mailcreator(sahteic,musteri1)	# Sahte Kurum İçi > Müşteri 1
mailcreator(lostar,musteri1)	# Gercek Dış Hesap > Müşteri 1
mailcreator(musteri1,lostar)	# Müşteri 1 > Gerçek Dış Hesap
mailcreator(sahteic,lostar)	# Sahte Kurum İçi > Gerçek Dış Hesap
mailcreator(sahtedis,musteri1)	# bill.gates > Müşteri 1
mailcreator(sahtedis,tempmail)	# bill.gates > tempmail
